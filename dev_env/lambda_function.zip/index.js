exports.handler = (event, context, callback) => {

    console.log(event);
    // Confirm the user
    const clientMetadata = event.request.clientMetadata
    // Set the email as verified if it is in the request
    if (clientMetadata && clientMetadata.hasOwnProperty("confirmUser") && clientMetadata["confirmUser"] == "auto") {
        event.response.autoVerifyEmail = true;
        event.response.autoConfirmUser = true;
    }

    // Return to Amazon Cognito
    callback(null, event);
};
